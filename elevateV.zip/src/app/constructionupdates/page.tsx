import React from 'react'

function constructionupdates() {
  return (
    <div>constructionupdates</div>
  )
}

export default constructionupdates