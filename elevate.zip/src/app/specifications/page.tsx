import React from 'react'

function specifications() {
  return (
    <div>Specifications</div>
  )
}

export default specifications